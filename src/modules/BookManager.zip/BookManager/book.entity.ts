import { Task } from "../taskManager/task.entity";

export interface Book {
  id: string;
  title: string;
  author: string;
  pages: number;
  isRead: boolean;
  createdAt: Date;
}

export interface BookData {
  getAllBooks: () => Promise<Book[]>;
  createBook: (title: string, author: string, pages: number) => Promise<Book>;
  getBook: (id: string) => Promise<Book | undefined>;
  updateBook: (
    id: string,
    title: string,
    author: string,
    pages: number,
  ) => Promise<Book | undefined>;
  deleteBook: (id: string) => Promise<Book | undefined>;
}
