import { db } from "../../db";
import { books } from "../../db/schema/books";
import { Book, BookData } from "./book.entity";

class BookRepository implements BookData {
  async getAllBooks(): Promise<Book[]> {
    return await db.select().from(books);
  }

  async createBook(
    title: string,
    author: string,
    pages: number,
  ): Promise<Book> {
    const newBook = {
      title,
      author,
      pages,
    };

    const [book] = await db.insert(books).values(newBook).returning();

    return book;
  }

  async getBook(id: string): Promise<Book | undefined> {
    const newGetBook = {
        id,
    };

    const [newBookById] = await db.insert(books).values(newGetBook).returning

    
  }
}

export { BookRepository };
